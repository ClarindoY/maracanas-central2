import {documentRadar} from './document-radar.mjs';
import {operations} from './operations.mjs';
import {openLibrary} from './library.mjs';
import {openMarketing} from './marketing.mjs';
import {setProgress} from './progress.mjs';
import {setDefaultResultOrder} from 'node:dns';
setDefaultResultOrder('ipv4first');
import {openWorkspace,allowed,fail} from './workspace.mjs';
import {createOfficialQueue} from './official-analysis.mjs';
import {summarize} from './summary.mjs';
import {recoverPending} from './summary-recovery.mjs';
import {makeBackup} from './backups.mjs';
import {initializeDemo} from './demo.mjs';
import {hostingConfig,securityHeaders,sessionCookie,clientIP,serveStatic} from './hosting.mjs';
import {enabledSources,searchSource,sourceDetail} from './multisources.mjs';
import {createServer} from 'node:http';
import {remoteURL,fetchPNCP} from './pncp.mjs';
import {openAuth,verifyPassword,hashPassword,token,permissions} from './auth.mjs';
const hosting=hostingConfig();const auth=openAuth();await initializeDemo(auth);const dummy=await hashPassword(token());let active=0,authActive=0;
const marketing=openMarketing(auth);
const work=openWorkspace(auth);const library=openLibrary(auth);const ops=operations(auth,work,library);const radar=documentRadar({work,library});let summaryActive=false;
const officialQueue=createOfficialQueue(work,async(user,id,docs)=>{if(summaryActive)throw Error('Outra análise está em andamento. Solicite novamente.');summaryActive=true;try{return await summarize(work,user,id,docs);}finally{summaryActive=false;}});
if(process.env.BACKUP_ENABLED==='true'){try{makeBackup(auth,work.dir);}catch(e){console.error('Backup falhou: '+e.message);}setInterval(()=>{try{makeBackup(auth,work.dir);}catch(e){console.error('Backup falhou: '+e.message);}},3600000).unref();}
const origins=hosting.origins;
async function body(req){let data='';for await(const chunk of req){data+=chunk;if(Buffer.byteLength(data)>(req.url==='/api/marketing/intelligence'?12000000:req.url?.startsWith('/api/work/')||req.url?.startsWith('/api/marketing/')?262144:16384))throw new Error('Corpo excede limite.');}return JSON.parse(data||'{}');}
export const server=createServer(async(req,res)=>{
 for(const [key,value] of Object.entries(securityHeaders(hosting.production)))res.setHeader(key,value);
 function reply(status,data){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','X-Frame-Options':'DENY'});res.end(JSON.stringify(data));}
 try {
 if(hosting.production?!hosting.hosts.has(req.headers.host||''):!/^(localhost|127\.0\.0\.1)(:\d+)?$/.test(req.headers.host||''))return reply(403,{error:'Host não permitido.'});
 const u=new URL(req.url,'http://localhost');
 if(u.pathname==='/api/health'&&req.method==='GET'){auth.db.prepare('SELECT 1').get();return reply(200,{ok:true});}
 if(hosting.production&&req.headers['x-forwarded-proto']!=='https'){res.writeHead(308,{Location:hosting.primary+u.pathname+u.search});return res.end();}
 if(!u.pathname.startsWith('/api/')){if(hosting.production&&await serveStatic(req,res,u))return;return reply(404,{error:'Página não encontrada.'});}
 if(req.method!=='GET'&&(!origins.has(req.headers.origin)||!(req.headers['content-type']?.startsWith('application/json')||(req.method==='POST'&&(/^\/api\/work\/tenders\/[^/]+\/documents$/.test(u.pathname)||(u.pathname==='/api/library/documents'&&req.headers['content-type']==='application/pdf'||u.pathname==='/api/library/import-zip'&&req.headers['content-type']==='application/zip'))))))return reply(403,{error:'Origem ou formato não permitido.'});
 const raw=(req.headers.cookie||'').split(';').map(s=>s.trim()).find(s=>s.startsWith(hosting.cookieName+'='))?.slice(hosting.cookieName.length+1);
 if(u.pathname==='/api/auth/login'&&req.method==='POST'){
 const b=await body(req);const login=String(b.login||'').trim().toLowerCase();const ip=clientIP(req,hosting);
 if(auth.blocked('ip:'+ip)||auth.blocked('user:'+login))return reply(429,{error:'Muitas tentativas. Aguarde 15 minutos.'});
 if(authActive>=3)return reply(429,{error:'Aguarde e tente novamente.'});
 const user=auth.db.prepare('SELECT * FROM users WHERE login=?').get(login);let ok;authActive++;try{ok=await verifyPassword(b.password,user?.password||dummy);}finally{authActive--;}
 if(!ok||!user?.active){auth.fail('ip:'+ip);auth.fail('user:'+login);auth.audit('anônimo','Falha de login');return reply(401,{error:'Login ou senha inválidos.'});}
 auth.clear('user:'+login);const s=auth.createSession(user.id,b.remember===true);res.setHeader('Set-Cookie',sessionCookie(hosting,s.raw,b.remember===true));auth.audit(user.id,'Login concluído');work.event(auth.pub(user),'Login concluído',null);return reply(200,{user:auth.pub(user),csrf:s.csrf});
 }
 const session=auth.session(raw);
 if(!session)return reply(401,{error:'Entre com login e senha.'});
 if(req.method!=='GET'&&req.headers['x-csrf-token']!==session.csrf)return reply(403,{error:'Sessão inválida. Refaça o login.'});
 if(u.pathname==='/api/auth/me'&&req.method==='GET')return reply(200,session);
 if(u.pathname==='/api/auth/logout'&&req.method==='POST'){auth.logout(raw);auth.audit(session.user.id,'Logout concluído');work.event(session.user,'Logout concluído',null);res.setHeader('Set-Cookie',sessionCookie(hosting,''));return reply(200,{ok:true});}
 if(u.pathname==='/api/auth/password'&&req.method==='POST'){const b=await body(req);const user=auth.db.prepare('SELECT * FROM users WHERE id=?').get(session.user.id);if(!await verifyPassword(b.current,user.password))return reply(401,{error:'Senha atual inválida.'});const h=await hashPassword(b.next);auth.db.prepare('UPDATE users SET password=? WHERE id=?').run(h,user.id);auth.db.prepare('DELETE FROM sessions WHERE user_id=?').run(user.id);auth.audit(user.id,'Senha alterada e sessões encerradas');work.event(session.user,'Senha alterada',null);return reply(200,{ok:true});}

 if(u.pathname.startsWith('/api/marketing/')){
 if(u.pathname==='/api/marketing/intelligence'&&req.method==='GET')return reply(200,marketing.intelligence(session.user,{kind:u.searchParams.get('kind'),dnaId:u.searchParams.get('dnaId')??'default'}));
 if(u.pathname==='/api/marketing/intelligence'&&req.method==='POST')return reply(201,await marketing.exploreIntelligence(session.user,await body(req)));
 if(u.pathname==='/api/marketing/perspectives/saved'&&req.method==='POST')return reply(200,marketing.savePerspectiveIdea(session.user,await body(req)));
 if(u.pathname==='/api/marketing/perspectives'&&req.method==='GET')return reply(200,marketing.perspectives(session.user,u.searchParams.get('folderId')||''));
 if(u.pathname==='/api/marketing/perspectives'&&req.method==='POST')return reply(201,await marketing.explorePerspective(session.user,await body(req)));
 if(u.pathname==='/api/marketing/academy'&&req.method==='GET')return reply(200,marketing.academy(session.user,u.searchParams.get('dnaId')||'default'));
 if(u.pathname==='/api/marketing/academy/favorite'&&req.method==='POST')return reply(200,marketing.saveAcademyFavorite(session.user,await body(req)));
 if(u.pathname==='/api/marketing/folders'&&req.method==='GET')return reply(200,marketing.folders(session.user));
 if(u.pathname==='/api/marketing/folders'&&req.method==='POST')return reply(201,marketing.createFolder(session.user,await body(req)));
 const folderMatch=u.pathname.match(/^\/api\/marketing\/folders\/([a-zA-Z0-9-]+)$/);
 if(folderMatch&&req.method==='PATCH')return reply(200,marketing.patchFolder(session.user,folderMatch[1],await body(req)));
 if(u.pathname==='/api/marketing/brands'&&req.method==='GET')return reply(200,marketing.brands(session.user));
 if(u.pathname==='/api/marketing/brands'&&req.method==='POST')return reply(201,marketing.createBrand(session.user,await body(req)));
 if(u.pathname==='/api/marketing/profiles'&&req.method==='GET')return reply(200,marketing.profiles(session.user));
 if(u.pathname==='/api/marketing/profiles'&&req.method==='POST')return reply(201,marketing.createProfile(session.user,await body(req)));
 if(u.pathname==='/api/marketing/profile/suggest'&&req.method==='POST')return reply(200,await marketing.suggestProfile(session.user,await body(req)));
 if(u.pathname==='/api/marketing/profile'&&req.method==='GET')return reply(200,marketing.profile(session.user,u.searchParams.get('id')??'default'));
 if(u.pathname==='/api/marketing/profile'&&req.method==='PUT')return reply(200,marketing.saveProfile(session.user,await body(req)));
 if(u.pathname==='/api/marketing/contents'&&req.method==='GET')return reply(200,marketing.list(session.user));
 if(u.pathname==='/api/marketing/generate'&&req.method==='POST')return reply(201,await marketing.create(session.user,await body(req)));
 const match=u.pathname.match(/^\/api\/marketing\/contents\/([a-zA-Z0-9-]+)(\/versions|\/comments|\/revise)?$/);
 if(match){
 if(match[2]==='/comments'&&req.method==='GET')return reply(200,marketing.comments(session.user,match[1]));
 if(match[2]==='/comments'&&req.method==='POST')return reply(201,marketing.comment(session.user,match[1],await body(req)));
 if(match[2]==='/revise'&&req.method==='POST')return reply(200,await marketing.revise(session.user,match[1],await body(req)));
 if(match[2]==='/versions'&&req.method==='GET')return reply(200,marketing.versions(session.user,match[1]));
 if(!match[2]&&req.method==='GET')return reply(200,marketing.get(session.user,match[1]));
 if(!match[2]&&req.method==='PATCH')return reply(200,marketing.patch(session.user,match[1],await body(req)));
 if(!match[2]&&req.method==='DELETE')return reply(200,marketing.remove(session.user,match[1],(await body(req)).version));
 }
 return reply(404,{error:'Rota Marketing não encontrada.'});
 }
 if(u.pathname==='/api/work/dashboard-docs'&&req.method==='GET'){if(!allowed(session.user,'Acessar documentos'))fail(403,'Sem acesso.');return reply(200,auth.db.prepare("SELECT id,name,company_id,expires_at,uploaded_by owner FROM library_documents WHERE status NOT IN ('Removido','Rejeitado') AND expires_at BETWEEN date('now','-3 hours') AND date('now','-3 hours','+30 days')").all());}
 if(u.pathname.startsWith('/api/library/')){
 if(u.pathname==='/api/library/prepare'&&req.method==='POST')return reply(202,ops.queue(session.user,(await body(req)).company));
 if(u.pathname==='/api/library/proposal'&&req.method==='POST')return reply(200,ops.proposal(session.user,await body(req)));
 if(u.pathname==='/api/library/radar'&&req.method==='POST')return reply(200,await radar(session.user,await body(req)));
 if(u.pathname==='/api/library/trash'&&req.method==='GET')return reply(200,library.trash(session.user,u.searchParams.get('company')||'maracanas'));
 if(u.pathname==='/api/library/report'&&req.method==='GET')return reply(200,library.report(session.user,u.searchParams.get('company')||'maracanas'));
 if(u.pathname==='/api/library/comparisons'&&req.method==='GET')return reply(200,library.listComparisons(session.user,u.searchParams.get('company')||'maracanas'));
 if(u.pathname==='/api/library/comparisons'&&req.method==='POST')return reply(201,await library.compare(session.user,await body(req)));
 const cr=u.pathname.match(/^\/api\/library\/comparisons\/([a-fA-F0-9-]{36})$/);
 if(cr&&req.method==='GET')return reply(200,library.getComparison(session.user,cr[1]));
 if(u.pathname==='/api/library/search'&&req.method==='GET')return reply(200,library.search(session.user,{companyId:u.searchParams.get('company')||'',query:u.searchParams.get('q')||''}));
 if(u.pathname==='/api/library/index-progress'&&req.method==='GET')return reply(200,ops.progress(session.user,u.searchParams.get('company')||''));
 if(u.pathname==='/api/library/index-batch'&&req.method==='POST'){const data=await body(req);return reply(200,await library.indexBatch(session.user,data.companyId));}
 if(u.pathname==='/api/library/config'&&req.method==='GET')return reply(200,{companies:library.companies,categories:library.categories});
 if(u.pathname==='/api/library/batches'&&req.method==='GET')return reply(200,library.batches(session.user,u.searchParams.get('company')||'maracanas'));
 const batchRoute=u.pathname.match(/^\/api\/library\/batches\/([a-fA-F0-9-]{36})\/cancel$/);
 if(batchRoute&&req.method==='POST')return reply(200,library.cancelBatch(session.user,batchRoute[1],await body(req)));
 if(u.pathname==='/api/library/documents'&&req.method==='GET')return reply(200,library.list(session.user,u.searchParams.get('company')||''));
 if(u.pathname==='/api/library/import-zip'&&req.method==='POST'){
 let size=0;const chunks=[];const max=Number(process.env.MAX_LIBRARY_ZIP_BYTES||260*1024*1024);
 for await(const c of req){size+=c.length;if(size>max)fail(413,'ZIP excede o limite configurado.');chunks.push(c);}
 let name;try{name=decodeURIComponent(req.headers['x-file-name']||'');}catch{fail(400,'Nome inválido.');}
 const saved=library.uploadZip(session.user,{companyId:req.headers['x-company-id'],category:decodeURIComponent(req.headers['x-category']||''),name},Buffer.concat(chunks));ops.queue(session.user,req.headers['x-company-id']);return reply(201,saved);
 }
 if(u.pathname==='/api/library/documents'&&req.method==='POST'){
 let size=0;const chunks=[];for await(const c of req){size+=c.length;if(size>20*1024*1024)fail(413,'Limite de 20 MB por PDF.');chunks.push(c);}
 let name;try{name=decodeURIComponent(req.headers['x-file-name']||'');}catch{fail(400,'Nome inválido.');}
 const saved=library.upload(session.user,{companyId:req.headers['x-company-id'],category:decodeURIComponent(req.headers['x-category']||''),name,sourceTenderId:req.headers['x-source-tender-id']||null},Buffer.concat(chunks));ops.queue(session.user,req.headers['x-company-id']);return reply(201,saved);
 }
 const readOne=u.pathname.match(/^\/api\/library\/documents\/([a-fA-F0-9-]{36})\/(index|analysis|analysis-review)$/);
 if(readOne){
   if(readOne[2]==='index'&&req.method==='POST')return reply(200,await library.indexOne(session.user,readOne[1],await body(req)));
   if(readOne[2]==='analysis'&&req.method==='GET')return reply(200,library.getAnalysis(session.user,readOne[1]));
   if(readOne[2]==='analysis'&&req.method==='POST')return reply(200,await library.analyze(session.user,readOne[1]));
   if(readOne[2]==='analysis-review'&&req.method==='POST')return reply(200,library.reviewAnalysis(session.user,readOne[1],await body(req)));
 }
 const restoreRoute=u.pathname.match(/^\/api\/library\/documents\/([a-fA-F0-9-]{36})\/restore$/);
 if(restoreRoute&&req.method==='POST')return reply(200,library.restore(session.user,restoreRoute[1],await body(req)));
 const lm=u.pathname.match(/^\/api\/library\/documents\/([a-zA-Z0-9-]+)(?:\/(review|history|file|metadata))?$/);
 if(lm){if(!lm[2]&&req.method==='DELETE')return reply(200,library.remove(session.user,lm[1],await body(req)));
 if(lm[2]==='metadata'&&req.method==='PATCH')return reply(200,library.updateMetadata(session.user,lm[1],await body(req)));
 if(lm[2]==='review'&&req.method==='POST')return reply(200,library.review(session.user,lm[1],await body(req)));
 if(lm[2]==='history'&&req.method==='GET')return reply(200,library.history(session.user,lm[1]));
 if(lm[2]==='file'&&req.method==='GET'){const d=library.download(session.user,lm[1]);res.writeHead(200,{'Content-Type':'application/pdf','Content-Disposition':"attachment; filename*=UTF-8''"+encodeURIComponent(d.metadata.name),'Content-Length':d.bytes.length,'Cache-Control':'no-store'});return res.end(d.bytes);}}
 return reply(404,{error:'Rota da biblioteca não encontrada.'});
 }
 if(u.pathname.startsWith('/api/work/')){
 if(!session.user.admin&&!session.user.permissoes.some(p=>['Buscar editais','Analisar editais','Registrar decisões','Montar propostas','Acessar documentos'].includes(p)))return reply(403,{error:'Nenhuma permissão de trabalho foi atribuída à sua conta.'});
 if(u.pathname==='/api/work/team'&&req.method==='GET')return reply(200,auth.users().filter(x=>x.ativo).map(x=>({id:x.id,nome:x.nome})));
 if(u.pathname==='/api/work/tenders'&&req.method==='GET')return reply(200,work.list());
 if(u.pathname==='/api/work/tenders'&&req.method==='POST')return reply(201,work.create(session.user,await body(req)));
 if(u.pathname==='/api/work/audit'&&req.method==='GET'){if(!session.user.admin)return reply(403,{error:'Auditoria exclusiva da administração.'});const actor=u.searchParams.get('actor')||'';const page=Math.max(1,Math.min(10000,Number(u.searchParams.get('page'))||1));return reply(200,work.db.prepare('SELECT * FROM activity WHERE (?=\'\' OR actor=?) ORDER BY id DESC LIMIT 100 OFFSET ?').all(actor,actor,(page-1)*100));}
 const m=u.pathname.match(/^\/api\/work\/tenders\/([^/]+)(?:\/(documents|comments|summary|summary-recovery|official-analysis)(?:\/([^/]+))?)?$/);if(!m)return reply(404,{error:'Rota não encontrada.'});const id=decodeURIComponent(m[1]);
 if(!m[2]&&req.method==='GET')return reply(200,work.detail(session.user,id));
 if(!m[2]&&req.method==='PATCH')return reply(200,work.patch(session.user,id,await body(req)));
 if(m[2]==='official-analysis'&&req.method==='GET'){const job=officialQueue.status(id);return reply(200,job?{...job,progress:work.get(id).analysisProgress||null}:null);}
 if(m[2]==='official-analysis'&&req.method==='POST')return reply(202,officialQueue.start(session.user,id));
 if(m[2]==='comments'&&req.method==='POST'){const b=await body(req);work.comment(session.user,id,b.text);return reply(200,work.detail(session.user,id));}
 if(m[2]==='documents'&&!m[3]&&req.method==='POST'){if(!allowed(session.user,'Acessar documentos'))return reply(403,{error:'Sem permissão para documentos.'});let size=0;const chunks=[];for await(const c of req){size+=c.length;if(size>20*1024*1024)fail(413,'Limite: 20 MB por PDF.');chunks.push(c);}let name;try{name=decodeURIComponent(req.headers['x-file-name']||'');}catch{fail(400,'Nome inválido.');}return reply(201,work.upload(session.user,id,name,Buffer.concat(chunks)));}
 if(m[2]==='documents'&&m[3]&&req.method==='GET'){const d=work.document(session.user,id,m[3]);res.writeHead(200,{'Content-Type':'application/pdf','Content-Disposition':"attachment; filename*=UTF-8''"+encodeURIComponent(d.metadata.name),'Content-Length':d.bytes.length,'Cache-Control':'no-store'});return res.end(d.bytes);}
 if(m[2]==='summary-recovery'&&req.method==='POST'){if(summaryActive)return reply(429,{error:'Outra análise está em andamento.'});const b=await body(req);summaryActive=true;try{return reply(200,await recoverPending(work,session.user,id,b));}finally{summaryActive=false;}}
 if(m[2]==='summary'&&req.method==='GET')return reply(200,{progress:work.get(id).analysisProgress||null});
 if(m[2]==='summary'&&req.method==='POST'){if(!allowed(session.user,'Analisar editais')||!allowed(session.user,'Acessar documentos'))return reply(403,{error:'Sem permissão para resumir documentos.'});if(summaryActive)return reply(429,{error:'Outra análise está em andamento.'});const b=await body(req);summaryActive=true;try{return reply(200,await summarize(work,session.user,id,b.documentIds));}catch(e){setProgress(work,id,{status:'falhou'});throw e;}finally{summaryActive=false;}}
 return reply(405,{error:'Método não permitido.'});
 }
 if(u.pathname.startsWith('/api/admin/')){
 if(!session.user.admin)return reply(403,{error:'Acesso exclusivo da administradora.'});
 if(u.pathname==='/api/admin/users'&&req.method==='GET')return reply(200,auth.users());
 if(u.pathname==='/api/admin/audit'&&req.method==='GET')return reply(200,auth.db.prepare('SELECT time,actor,action FROM audit ORDER BY id DESC LIMIT 100').all());
 if(u.pathname==='/api/admin/users'&&req.method==='POST'){const b=await body(req);const login=String(b.login||'').toLowerCase();if(!/^[a-z0-9._-]{3,64}$/.test(login)||!b.name?.trim()||!/^\S+@\S+\.\S+$/.test(b.email||''))return reply(400,{error:'Dados inválidos.'});const h=await hashPassword(b.password);auth.db.prepare('INSERT INTO users(id,name,login,email,password,permissions) VALUES(?,?,?,?,?,?)').run(token(),b.name.trim(),login,b.email.trim().toLowerCase(),h,JSON.stringify((b.permissions||[]).filter(p=>permissions.includes(p))));auth.audit(session.user.id,'Funcionário criado');work.event(session.user,'Funcionário criado',null,{login,name:b.name.trim(),permissions:(b.permissions||[]).filter(p=>permissions.includes(p))});return reply(201,{ok:true});}
 if(u.pathname==='/api/admin/users'&&req.method==='PATCH'){const b=await body(req);const target=auth.db.prepare('SELECT * FROM users WHERE id=?').get(b.id);if(!target||target.admin)return reply(400,{error:'Perfil inválido ou administrador protegido.'});auth.db.prepare('UPDATE users SET active=?,permissions=? WHERE id=?').run(b.active===true?1:0,JSON.stringify((b.permissions||[]).filter(p=>permissions.includes(p))),b.id);auth.db.prepare('DELETE FROM sessions WHERE user_id=?').run(b.id);auth.audit(session.user.id,'Permissões/status alterados; sessões revogadas');work.event(session.user,'Permissões e acesso alterados',null,{targetId:target.id,before:{active:!!target.active,permissions:JSON.parse(target.permissions)},after:{active:b.active===true,permissions:(b.permissions||[]).filter(p=>permissions.includes(p))}});return reply(200,{ok:true});}
 }
 if(u.pathname.startsWith('/api/sources')){
 if(req.method!=='GET')return reply(405,{error:'Método não permitido.'});
 if(!session.user.admin&&!session.user.permissoes.includes('Buscar editais'))return reply(403,{error:'Sem permissão para buscar editais.'});
 if(u.pathname==='/api/sources')return reply(200,enabledSources);
 const m=u.pathname.match(/^\/api\/sources\/(am|mg|rs|sesc|rj)\/(search|detail)$/);
 if(!m)return reply(404,{error:'Fonte não encontrada.'});
 if(active>=1)return reply(429,{error:'Aguarde as consultas em andamento.'});
 work.event(session.user,'Consulta em fonte complementar',null,{source:m[1],action:m[2],query:u.searchParams.get('q')||''});active++;try{return reply(200,m[2]==='search'?await searchSource(m[1],u.searchParams.get('q'),Number(u.searchParams.get('page')||1)):await sourceDetail(m[1],u.searchParams.get('id')||''));}catch(e){return reply(502,{error:e.message});}finally{active--;}
 }
 if(u.pathname.startsWith('/api/pncp-proxy/')){if(!session.user.admin&&!session.user.permissoes.includes('Buscar editais'))return reply(403,{error:'Sem permissão para buscar editais.'});let remote;try{remote=remoteURL(req.url);}catch(e){return reply(400,{error:e.message});}if(active>=4)return reply(429,{error:'Aguarde as consultas.'});work.event(session.user,'Consulta PNCP',null,{path:remote.pathname,query:remote.search});active++;try{return reply(200,await fetchPNCP(remote));}catch(e){console.error('PNCP falhou:',e.cause?.code||e.code||e.message);return reply(502,{error:'Falha ao consultar PNCP: '+(e.cause?.code||e.message)});}finally{active--;}}
 return reply(404,{error:'Rota não encontrada.'});
 }catch(e){reply(e.status||400,{error:e.status?e.message:e.code?.includes('CONSTRAINT')?'Login ou e-mail já cadastrado.':'Operação inválida. Confira os dados e tente novamente.'});}
});

server.listen(Number(process.env.PORT||3001),hosting.production?'0.0.0.0':'127.0.0.1',()=>console.log('Servidor Maracanãs pronto na porta '+Number(process.env.PORT||3001)));
process.on('SIGTERM',()=>server.close(()=>{auth.db.close();process.exit(0);}));
